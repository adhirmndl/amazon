<?php
require_once("../dbcon/dbcon.php");
//CREATE QUERY TO DB AND PUT RECEIVED DATA INTO ASSOCIATIVE ARRAY
if (isset($_REQUEST['query'])) {
    $seller_id='abc';
    $query = $_REQUEST['query'];
    $sql = mysqli_query ($dbhandle,"SELECT * FROM product WHERE lower(concat(asin,name)) LIKE '%{$query}%'");
	$array = array();
    while ($row = mysqli_fetch_array($sql)) {
        $array[] = array (
            'label' => $row['asin'].', '.$row['name'],
            'value' => $row['name']."<a href='/amazon/list_preview.php?asin=".$row['asin']."'
   onclick='window.open(this.href,\"targetWindow\",\"toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=950,height=650\"); return false;'>Preview</a>&nbsp;<a href='list_product.php?asin=".$row['asin']."&seller=".$seller_id."' style='text-decoration:none'><button>List Product</button></a>" 
        );
    }
    //RETURN JSON ARRAY
    
    echo json_encode ($array);
}

?>