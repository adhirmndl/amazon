<?php
if (isset($_GET["seller"])){
	require_once("../dbcon/dbcon.php");

	$sql='SELECT name,price FROM `listing`,`product` WHERE listing.asin = product.asin and `seller` = "abc" ';
	//$sql = 'SELECT `product.name`,`listing.price` FROM `listing`,`product` WHERE  `listing.asin` =`product.asin` and `listing.seller` = "'.$_GET["seller"].'"';
	echo $sql;
	$output = mysqli_query($dbhandle,$sql);
	$no = mysqli_num_rows($output);
	if($no>0){
		echo "<table>
	<tr>
		<th>Product Name</th>
		<th>My Price</th>
		<th>Buy Box Price</th>
		<th>Action</th>
	</tr>";
		while($p = mysqli_fetch_array($output)){
			echo "<tr><td>".$p['name']."</td><td>".$p['price']."</td><td>".$p['name']."</td><td>hello</td></tr>";
		}

	}

}
else{
	echo "invalid Request";
}

?>

</table>
