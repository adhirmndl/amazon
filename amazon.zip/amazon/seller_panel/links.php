<?php require_once("head.php");?><a href="login.php">Login Here</a><br>
<a href="../seller_rgst.php">Seller Registration Here</a><br>
<a href="list_product.php?asin=B00LIWQJ3U&seller=abc">List Product</a><br>
<a href="seller_balance_details.php">Seller Balance Details</a><br>
<a href="pendingOrders.php?seller_id=abc">Pending Orders</a>