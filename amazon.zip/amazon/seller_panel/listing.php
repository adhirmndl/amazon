<!doctype html>
<html>
	<head>
	<meta charset="utf-8">
	<title>Listing</title>
	</head>
		<body>
			<form action="saveListingData.php" method="post" enctype="multipart/form-data" name="liting">
				ASIN : <input type="text" name="asin" required="required"><br>
				Seller : <input type="text" name="seller" required="required"><br>
				Price : <input type="text" name="price" required="required"><br>
				Shipping Price : <input type="text" name="shipping_price" required="required"><br>
				Quantity : <input type="text" name="qty" required="required"><br>
				<input type="submit" name="Submit" value="Add Item" />
			</form>
			
		</body>
</html>