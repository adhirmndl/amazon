<?php
	ob_start();
	session_start();
	error_reporting(0);

	require_once("dbcon/dbcon.php");

	$sql1="insert into listing(`asin`,`seller`,`price`,`shipping_price`) 
		 	values('".$_POST['asin']."','".$_POST['seller']."','".$_POST['price']."','".$_POST['shipping_price']."','".$_POST['qty']."')";
	$query1=mysqli_query($dbhandle,$sql1);




	$query2=mysqli_query($dbhandle,"select * from product");
	$op=mysqli_fetch_array($query2);
	echo $op['design'];
?>