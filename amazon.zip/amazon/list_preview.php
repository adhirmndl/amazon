<?php
$host='localhost';
$user='root';
$password='';
$db = 'amazon';

$dh=mysqli_connect($host,$user,$password,$db);
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
mysqli_select_db($dh,$db);


	if (isset($_GET["asin"])){
		$sql =  "SELECT * FROM `product`";
		$output = mysqli_query($dh,$sql);$no = mysqli_num_rows($output);
		if ($no>0){
			$p = mysqli_fetch_array($output);
			echo "<h1>".$p["name"]."</h1><br><br><br><Specification:<br>".$p["specification"]."<br><br><br>From the  Manufacturar:<br>".$p["design"];
		}

	}
?>