
<?php require_once("../dbcon/dbcon.php");?>

<!DOCTYPE html>
<html>
<head>
    <title>Product search</title>

<!-- \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\  Textbox based Search scripts and css ////////////////////////////////////////// -->

        <meta http-equiv="Content-Language" content="en-us">
    <link href="search/bootstrap.min.css" rel="stylesheet">
    <script src="search/jquery-2.1.4.min.js"></script>
    <script src="search/bootstrap.min.js"></script>
    <script src="search/typeahead.js"></script>
    <style>      

        .tt-hint,
        .productName {
            border: 2px solid #CCCCCC;
            //border-radius: 8px 8px 8px 8px;
            font-size: 16px;
            height: 25px;
            line-height: 30px;
            outline: medium none;
            padding: 8px 12px;
            width: 200px;
        }

        .tt-dropdown-menu {
            width: 1000px;
            margin-top: 5px;
            padding: 8px 12px;
            background-color: #fff;
            border: 1px solid #ccc;
            border: 1px solid rgba(0, 0, 0, 0.2);
            //border-radius: 8px 8px 8px 8px;
            font-size: 14px;
            color: #111;
            background-color: #F1F1F1;
        }
    </style>
    <script>
        $(document).ready(function() {

            $('input.productName').typeahead({
                name: 'name',
                remote: 'getProduct.php?query=%QUERY'

            });

        })
    </script>
<!-- \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\  Textbox based Search scripts and css ////////////////////////////////////////// -->


</head>
<body>

</body>
</html>




<input type="text" name="name[]" id="name"  size="30" style="width: 1000px;" class="productName" placeholder="Enter the product name" required/>