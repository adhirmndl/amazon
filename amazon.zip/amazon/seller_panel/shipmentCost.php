<?php
	require_once("dbcon/dbcon.php");
	$seller_legal_name=$_GET['legal_name'];
	$weight=$_GET['weight'];
	$sql1="select * from seller where legal_name='".$seller_legal_name."'";
	//echo $sql1."\n\n";
	$query1=mysqli_query($dbhandle,$sql1);
	$op=mysqli_fetch_array($query1);
	$charge_data=$op['charge_data'];
	echo "\n\nCharge data : ".$charge_data."\n\n";
	$charge_data_array=explode('+', $charge_data);
	foreach ($charge_data_array as $value) {
		echo $value."\n";
	}


?>